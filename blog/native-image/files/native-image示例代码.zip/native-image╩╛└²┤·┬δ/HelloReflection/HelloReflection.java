public class HelloReflection {

    public static void foo() {
        System.out.println("Running foo");
    }

    public static void bar() {
        System.out.println("Running bar");
    }

    public static void main(String[] args) throws Exception {
        long t0 = System.nanoTime();

        for (String arg : args) {
            try {
                HelloReflection.class.getMethod(arg).invoke(null);
            } catch (ReflectiveOperationException ex) {
                System.out.println("Exception running '" + arg + "', error: "+ ex.getClass ().getSimpleName());
            }
        }

        System.out.println("time: " + (System.nanoTime() - t0));

        Thread.sleep(3000);
    }
}